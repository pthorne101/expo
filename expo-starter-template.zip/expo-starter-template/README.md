# Expo Starter Template

This is a simple starting point for new Expo-based mobile apps. Fork this repo and build on it for fast mobile development.

## Getting Started

```bash
npm install
npx expo start
```
