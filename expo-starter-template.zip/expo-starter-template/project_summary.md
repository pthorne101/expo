# Project Summary

This is a starter template for Expo-based React Native mobile apps. Use this as a base for future apps.

## Features

- Expo integration
- Navigation ready
- Clean file structure
- Placeholder assets and helper functions
