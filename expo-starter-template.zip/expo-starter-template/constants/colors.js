export default {
  primary: '#3B82F6',
  secondary: '#10B981',
  background: '#F9FAFB',
  text: '#111827',
};
